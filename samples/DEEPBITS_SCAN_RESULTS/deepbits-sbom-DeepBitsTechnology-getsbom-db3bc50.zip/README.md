# Introduction
This zip file contains two important files related to the software bill of materials (SBOM) for your project. The first file is a CycloneDX JSON file named [name].CycloneDX.json, which describes the components and dependencies used in your software project. The second file is a signature file named CycloneDX.signature.txt, which verifies the integrity and authenticity of the SBOM.

## Verifying the SBOM with the Signature File
To verify the SBOM using the provided signature file, please follow these steps:

1. Unzip the downloaded file and navigate to the unzipped directory.
2. Run the following command on your terminal or command prompt:
###
```bash
openssl x509 -pubkey -noout -in deepbits.cert | openssl dgst -verify /dev/stdin -keyform PEM -sha256 -signature CycloneDX.signature.bin -binary [name].CycloneDx.json
```

Remember to replace [name] with the actual downloads.